import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class BruteCollinearPoints {
  private final Point[] ps;

  public BruteCollinearPoints(Point[] points) {

    if (points == null) {
      throw new IllegalArgumentException();
    }
    
    for (Point point : points) {
      if (point == null) {
        throw new IllegalArgumentException();
      }
    }
    ps=points;
    Arrays.sort(ps);
  }

  public int numberOfSegments() {
    return segments().length;
  }

  public LineSegment[] segments() {
    if (ps.length < 4) {
      return new LineSegment[0];
    }
    List<LineSegment> ls = new ArrayList<>();
    for (int i = 0; i < ps.length; i++) {
      for (int j = i+1; j < ps.length; j++) {
        for (int j2 = j+1; j2 < ps.length; j2++) {
          for (int k = j2+1; k < ps.length; k++) {
            //find 4 differents points to check if they are collinear
            if(!ps[i].equals(ps[j]) && !ps[j].equals(ps[j2]) && !ps[j2].equals(ps[k])){
              double slope0 = ps[i].slopeTo(ps[j]);
              double slope1 = ps[j].slopeTo(ps[j2]);
              double slope2 = ps[j2].slopeTo(ps[k]);
              if (slope0 == slope1 && slope1 == slope2) {
                LineSegment ls0 = new LineSegment(ps[i], ps[k]);
                ls.add(ls0);
              }
            }
          }
        }
      }
    }
    return ls.toArray(new LineSegment[ls.size()]);
  }

}